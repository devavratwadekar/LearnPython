# name = input("What is your name ? ")
# length = len(name)
# num_char = str(length)
# print("Your name has " + num_char + " characters.")

a = 123
print(type(a))

print(10 + float("225.67"))
print(str(90) + str(12))